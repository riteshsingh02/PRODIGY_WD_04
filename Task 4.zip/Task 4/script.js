// JavaScript can be added for interactivity if needed
console.log("Portfolio website loaded!");
